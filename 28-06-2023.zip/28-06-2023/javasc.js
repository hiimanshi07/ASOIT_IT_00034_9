// var x=100;
// var y=20;

// x-=50;
// y+=10;

// document.write(x);
// document.write(y);
let x = 5;
let y = 2;
let z = x + y;

document.write(x);
document.write(y);
